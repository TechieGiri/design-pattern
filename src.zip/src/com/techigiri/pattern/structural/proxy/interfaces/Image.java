package com.techigiri.pattern.structural.proxy.interfaces;

public interface Image {

	public void display();
}
