package com.techigiri.pattern.structural.flyweight.interfaces;

public interface Shape {

	void draw();

}
