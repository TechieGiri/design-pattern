package com.techiegiri.pattern.creational.builder.interfaces;

public interface Packing {

	public String pack();
}
