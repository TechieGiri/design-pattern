package com.techiegiri.pattern.creational.abstractfactory.interfaces;

public interface Color {
	void fill();
}
