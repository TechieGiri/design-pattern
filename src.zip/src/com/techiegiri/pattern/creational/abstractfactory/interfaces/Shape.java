package com.techiegiri.pattern.creational.abstractfactory.interfaces;

public interface Shape {

	void draw();
}
