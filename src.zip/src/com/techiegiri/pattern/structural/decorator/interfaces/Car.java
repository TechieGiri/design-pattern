package com.techiegiri.pattern.structural.decorator.interfaces;

public interface Car {

	public void assemble();

}
