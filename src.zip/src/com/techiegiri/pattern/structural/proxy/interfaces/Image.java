package com.techiegiri.pattern.structural.proxy.interfaces;

public interface Image {

	public void display();
}
