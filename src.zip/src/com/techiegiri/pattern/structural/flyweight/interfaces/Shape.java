package com.techiegiri.pattern.structural.flyweight.interfaces;

public interface Shape {

	void draw();

}
