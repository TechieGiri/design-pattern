package com.techiegiri.pattern.structural.bridge.interfaces;

public interface Color {

	public void applyColor();

}
