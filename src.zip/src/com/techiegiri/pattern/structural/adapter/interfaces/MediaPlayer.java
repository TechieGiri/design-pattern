package com.techiegiri.pattern.structural.adapter.interfaces;

public interface MediaPlayer {

	public void play(String fileType, String fileName);
}
