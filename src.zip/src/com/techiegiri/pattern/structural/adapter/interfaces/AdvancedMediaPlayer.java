package com.techiegiri.pattern.structural.adapter.interfaces;

public interface AdvancedMediaPlayer {

	public void playVlc(String fileName);
	public void playMp4(String fileNamex);
}
