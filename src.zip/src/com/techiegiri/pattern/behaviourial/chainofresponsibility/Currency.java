package com.techiegiri.pattern.behaviourial.chainofresponsibility;

public class Currency {

	private int amt;
	
	public Currency(int amt) {
		this.amt = amt;
	}

	public int getAmt() {
		return amt;
	}

	public void setAmt(int amt) {
		this.amt = amt;
	}
}
