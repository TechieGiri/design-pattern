package com.techiegiri.pattern.behaviourial.state;

public interface State {

	public void doAction(Context context);
}
