package com.techiegiri.pattern.behaviourial.command.interfaces;


//Command
public interface Order {

	public void execute();
}
