package com.techiegiri.pattern.behaviourial.observer.interfaces;

import com.techiegiri.pattern.behaviourial.observer.Subject;

public interface Observer {
	public void update();

}
