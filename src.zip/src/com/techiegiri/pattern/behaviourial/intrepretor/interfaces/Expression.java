package com.techiegiri.pattern.behaviourial.intrepretor.interfaces;

public interface Expression {

	public boolean intrepret(String context);
}
