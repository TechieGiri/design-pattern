package com.techiegiri.pattern.behaviourial.visitor.interfaces;

import java.util.List;

public interface Visitor {

	public void visit(List<Product> product);
}
