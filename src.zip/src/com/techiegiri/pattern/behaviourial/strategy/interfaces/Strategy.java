package com.techiegiri.pattern.behaviourial.strategy.interfaces;

public interface Strategy {
	
	public int doOperation(int num1,int num2);

}
